if(message == "error"){
	Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'La calve de gafete no existe',
      });
}